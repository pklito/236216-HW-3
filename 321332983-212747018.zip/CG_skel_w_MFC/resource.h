//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by CG_skel_w_MFC.rc
//
#define IDD_DIALOG1                     101
#define IDD_DIALOG2                     102
#define IDD_DIALOG3                     106
#define IDD_DIALOG4                     109
#define IDC_EDIT1                       1000
#define IDC_CHECK1                      1001
#define IDC_EDIT2                       1001
#define IDC_SLIDER1                     1002
#define IDC_EDIT4                       1002
#define IDC_EDIT3                       1003
#define IDC_BUTTON1                     1004
#define IDC_MFCCOLORBUTTON1             1007

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        111
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
