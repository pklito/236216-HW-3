The following steps are needed in order to compile the skeleton as it is in VS2019:

	- Assuming you installed VS2019 Community Edition with "Workloads" of "Desktop Development with C++": Run Visual Studio Installer, click "Modify", go to tab "Individual Components" 
	  scroll down and choose "MFC and ATL support", click "Modify".
	- Build the skeleton